//Andhika Dwiki (Astra Polytechnic - IOT Smarthome Monitoring System ESP32)
package com.example.projeklogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ktx.Firebase;

public class register extends AppCompatActivity {
    TextView log;
    EditText inputFullname, inputPassword, inputConfirmPassword, inputEmail;
    String email, password, confirmPassword, Fullname;
    Button register_but;

    FirebaseAuth mAUTH;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAUTH = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_register);
        inputEmail=findViewById(R.id.Email_register);
        inputFullname=findViewById(R.id.Full_Name_register);
        inputPassword=findViewById(R.id.Password_register);
        inputConfirmPassword=findViewById(R.id.Confirm_PasswordRegister);
        register_but = findViewById(R.id.reg_but);
        register_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cekRegister();
            }
        });


    }
    private void cekRegister (){
        email = inputEmail.getText().toString();
        password=inputPassword.getText().toString();
        Fullname=inputFullname.getText().toString();
        confirmPassword=inputConfirmPassword.getText().toString();

        mAUTH.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(register.this, "Register Succeed !", Toast.LENGTH_LONG).show();}

                        else{Toast.makeText(register.this, "Register Failed !", Toast.LENGTH_LONG).show();
                        }
                    }

                });}

    public void Halaman_Login (View view) {
        Intent intent =  new Intent(register.this, login.class);
        startActivity(intent);
    }

  public void Already_Laman (View view) {
    Intent intent =  new Intent(register.this, login.class);
    startActivity(intent);
}
    public void Laman_Utama (View view) {
        Intent intent =  new Intent(register.this, MainActivity.class);
        startActivity(intent);
    }
}