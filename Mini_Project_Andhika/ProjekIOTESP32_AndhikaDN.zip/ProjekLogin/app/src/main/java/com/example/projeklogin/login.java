//Andhika Dwiki (Astra Polytechnic - IOT Smarthome Monitoring System ESP32)
package com.example.projeklogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.ktx.Firebase;

public class login extends AppCompatActivity {

    EditText inputEmail, inputPassword;
    String email, password;
    Button login_but;
    private FirebaseAuth mAuth;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button tombolLogin = findViewById((R.id.login_but));

        mAuth = FirebaseAuth.getInstance();
        inputEmail = findViewById(R.id.email_login);
        inputPassword = findViewById(R.id.password_login);
        login_but = findViewById(R.id.login_but);
        login_but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cekLogin();
                    Intent intent = new Intent(login.this, PilihFitur.class);
                    startActivity(intent);
                }


        });


}
    public void Laman_Utama (View view) {
        Intent intent =  new Intent(login.this, MainActivity.class);
        startActivity(intent);
    }
    public void Login_buttons (View view) {
        Intent intent = new Intent(login.this, PilihFitur.class);
        startActivity(intent);
    }



    public void Register_Halaman(View view) {
        Intent intent = new Intent(login.this, register.class);
        startActivity(intent);
    }

private void cekLogin (){
        email = inputEmail.getText().toString();
        password=inputPassword.getText().toString();
        mAuth.signInWithEmailAndPassword(email,password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(login.this, "Login Succeed !", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(login.this, PilihFitur.class);
                                startActivity(intent);
                            }

                        else{Toast.makeText(login.this, "Login Failed !", Toast.LENGTH_LONG).show();
                        }
                        }

                });}
}


