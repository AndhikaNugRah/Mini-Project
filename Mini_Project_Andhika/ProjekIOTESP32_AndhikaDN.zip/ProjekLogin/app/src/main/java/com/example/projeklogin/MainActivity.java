//Andhika Dwiki (Astra Polytechnic - IOT Smarthome Monitoring System ESP32)
package com.example.projeklogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button tombolLogin = findViewById((R.id.button_login_main));

    }

    public void Login_Laman(View view) {
        Intent intent =  new Intent(MainActivity.this, login.class);
        startActivity(intent);
    }
    public void Register_Laman(View view) {
        Intent intent =  new Intent(MainActivity.this, register.class);
        startActivity(intent);
    }
}