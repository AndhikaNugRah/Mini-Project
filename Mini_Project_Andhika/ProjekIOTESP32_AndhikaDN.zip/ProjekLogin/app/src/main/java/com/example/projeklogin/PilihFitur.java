//Andhika Dwiki (Astra Polytechnic - IOT Smarthome Monitoring System ESP32)
package com.example.projeklogin;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.os.Bundle;

public class PilihFitur extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pilih_fitur);
    }
    public void Laman_Monitoring (View view) {
        Intent intent =  new Intent(PilihFitur.this, MonitoringFiture.class);
        startActivity(intent);
    }

    public void Humid_Laman (View view) {
        Intent intent =  new Intent(PilihFitur.this, humid.class);
        startActivity(intent);
    }

    public void Control_Laman2 (View view) {
        Intent intent =  new Intent(PilihFitur.this, control_space.class);
        startActivity(intent);
    }
}