//Andhika Dwiki (Astra Polytechnic - IOT Smarthome Monitoring System ESP32)
package com.example.projeklogin;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class control_space extends AppCompatActivity {
    ToggleButton buttonLampu1;
    ToggleButton buttonLampu2;
    ToggleButton buttonLampu3;

    TextView Distance;
    TextView LDR;
    TextView statusMotion;
    TextView statusPir;

    String valueDistrance;
    String valueLDR;
    String valuePir;
    String valueLampu1;
    String valueLampu2;
    String valueLampu3;
    DatabaseReference dref;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.control_space);

        dref = FirebaseDatabase.getInstance().getReference();
        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                valueLampu1 = dataSnapshot.child("Node1/lampu1").getValue().toString();
                if (valueLampu1.equals("0"))
                    buttonLampu1.setChecked(false);
                else
                    buttonLampu1.setChecked(true);

                valueLampu2 = dataSnapshot.child("Node1/lampu2").getValue().toString();
                if (valueLampu2.equals("0"))
                    buttonLampu2.setChecked(false);
                else
                    buttonLampu2.setChecked(true);


                valueLampu3 = dataSnapshot.child("Node1/lampu3").getValue().toString();
                if (valueLampu3.equals("0"))
                    buttonLampu3.setChecked(false);
                else
                    buttonLampu3.setChecked(true);

            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    public void Laman_Utama (View view) {
        Intent intent = new Intent(control_space.this, PilihFitur.class);
        startActivity(intent);
    }
}
